# Change Log
All changes will be listed here (since version v.0.1.0)
Project uses [Semantic Versioning](http://semver.org/).

## [Unreleased]
### Added
- npm and Bower setup.

## [0.1.0] - 2016-05-19
### Added
- Library created.
- CHANGELOG.md, README.md, LICENSE.md files.
- Rating animations: basic, fade, grow, growRotate, slot, checkmark.
- index.html file with basic structure needed to use library.
- Gulpfile.js to generate css in expanded and minified version.
